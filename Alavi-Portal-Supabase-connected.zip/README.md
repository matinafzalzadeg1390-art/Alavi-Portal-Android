# پرتال علوی — انتشار وب با GitHub Pages و Supabase

## ساختار
- `web/`: برنامه وب استاتیک
- `supabase/schema.sql`: ساختار دیتابیس و سیاست‌های RLS
- `supabase/create-user.ts`: تابع امن ساخت/حذف/تغییر رمز حساب‌ها
- `.github/workflows/deploy.yml`: انتشار خودکار با GitHub Pages
- `android/`: پوسته اندروید (مستقل از انتشار وب)

## راه‌اندازی Supabase
1. در Authentication تنظیم کنید ورود Email/Password فعال باشد.
2. چون برنامه از ایمیل ساختگی به شکل `<کدملی>@alavi.app` برای ورود استفاده می‌کند، تأیید ایمیل باید برای این پروژه خاموش باشد.
3. SQL فایل `supabase/schema.sql` را در SQL Editor اجرا کنید.
4. اولین حساب مدیر را در Authentication بسازید و دستور INSERT کامنت‌شده انتهای schema.sql را با کد ملی و نام واقعی همان حساب اجرا کنید.
5. تابع `create-user` را از فایل `supabase/create-user.ts` به‌عنوان Supabase Edge Function منتشر کنید. تأیید JWT برای این تابع باید روشن بماند.
6. در `web/config.js` آدرس Project URL و کلید عمومی Publishable پروژه علوی تنظیم شده‌اند. این کلید برای کد مرورگر است؛ امنیت داده‌ها باید با RLS اعمال شود.

**مهم:** کلید `service_role` یا `secret` را هرگز در فایل وب، GitHub، یا برنامه اندروید قرار ندهید. تابع Edge از Secret سمت سرور `SUPABASE_SERVICE_ROLE_KEY` استفاده می‌کند.

## انتشار GitHub Pages
1. محتویات پوشه `Alavi` را در ریشه مخزن GitHub قرار دهید (نه خود پوشه Alavi را).
2. شاخه اصلی مخزن باید `main` باشد.
3. در Settings → Pages، گزینه Build and deployment → Source را روی **GitHub Actions** بگذارید.
4. فایل‌های وب را در `web/` نگه دارید. با هر push به `main`، workflow اجرا و سایت منتشر می‌شود.
5. آدرس سایت به شکل `https://USERNAME.github.io/REPOSITORY/` خواهد بود.

## وضعیت عملکرد
صفحه فعلی قابلیت ورود، پروفایل، نمرات، حضور و غیاب و اطلاعیه‌ها را از Supabase می‌خواند/می‌نویسد. پیام‌رسان و گروه‌ها در این نسخه پیاده‌سازی نشده‌اند و نباید به‌عنوان قابلیت فعال معرفی شوند.
