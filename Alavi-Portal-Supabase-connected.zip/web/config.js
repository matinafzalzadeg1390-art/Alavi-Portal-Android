// Public browser configuration for Alavi Portal.
// Publishable keys are designed for client-side use; protect data with RLS.
window.ALAVI = {
  url: "https://bzponqndexsyhdfhdbps.supabase.co",
  key: "sb_publishable_Q6OFaMq4mRG0kh4LhcEL5A_GodZWk3n"
};
