-- پرتال علوی — ساختار دیتابیس (در Supabase > SQL Editor اجرا کن)

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  national_id text unique not null,
  full_name text not null,
  role text not null default 'student' check (role in ('student','admin')),
  class_name text,
  phone text,
  created_at timestamptz not null default now()
);

create table public.announcements (
  id bigint generated always as identity primary key,
  title text not null,
  body text not null,
  kind text not null default 'general' check (kind in ('general','exam','event')),
  audience text not null default 'all',
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.grades (
  id bigint generated always as identity primary key,
  student_id uuid not null references public.profiles(id) on delete cascade,
  subject text not null,
  score numeric(4,2) not null check (score between 0 and 20),
  created_at timestamptz not null default now(),
  unique (student_id, subject)
);

create table public.attendance (
  id bigint generated always as identity primary key,
  student_id uuid not null references public.profiles(id) on delete cascade,
  day date not null default current_date,
  status text not null check (status in ('present','late','absent')),
  unique (student_id, day)
);

create or replace function public.is_admin() returns boolean
language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
$$;

create or replace function public.my_class() returns text
language sql security definer set search_path = public stable as $$
  select class_name from public.profiles where id = auth.uid()
$$;

alter table public.profiles enable row level security;
alter table public.announcements enable row level security;
alter table public.grades enable row level security;
alter table public.attendance enable row level security;

-- پروفایل: هر کس فقط خودش، مدیر همه
create policy "profiles read" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
create policy "profiles admin write" on public.profiles for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- اطلاعیه: همه‌ی کاربران وارد‌شده (طبق مخاطب)، فقط مدیر می‌نویسد
create policy "ann read" on public.announcements for select to authenticated
  using (public.is_admin() or audience = 'all' or audience = public.my_class());
create policy "ann admin write" on public.announcements for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- نمرات و حضور: دانش‌آموز فقط مال خودش، مدیر همه
create policy "grades read" on public.grades for select to authenticated using (student_id = auth.uid() or public.is_admin());
create policy "grades admin write" on public.grades for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "att read" on public.attendance for select to authenticated using (student_id = auth.uid() or public.is_admin());
create policy "att admin write" on public.attendance for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ===== اولین مدیر =====
-- ۱) در Authentication > Users یک کاربر بساز با ایمیل  کدملی@alavi.app  (مثلاً 0012345678@alavi.app) و تیک Auto Confirm.
-- ۲) بعد این دستور را با کد ملی و نام خودت اجرا کن:
--
-- insert into public.profiles (id, national_id, full_name, role)
-- select id, '0012345678', 'نام شما', 'admin' from auth.users where email = '0012345678@alavi.app';
