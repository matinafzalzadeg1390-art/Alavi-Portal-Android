// Edge Function: create-user  (Supabase > Edge Functions > Create function > نام: create-user)
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}
const j = (o: unknown, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { ...cors, 'Content-Type': 'application/json' } })

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const url = Deno.env.get('SUPABASE_URL')!
    const caller = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    })
    const { data: { user } } = await caller.auth.getUser()
    if (!user) return j({ error: 'وارد نشده‌اید' }, 401)

    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
    const { data: me } = await admin.from('profiles').select('role').eq('id', user.id).single()
    if (me?.role !== 'admin') return j({ error: 'دسترسی ندارید' }, 403)

    const b = await req.json()

    if (b.action === 'reset') {
      if (String(b.password || '').length < 6) return j({ error: 'رمز حداقل ۶ کاراکتر باشد' }, 400)
      const { error } = await admin.auth.admin.updateUserById(b.user_id, { password: b.password })
      return error ? j({ error: error.message }, 400) : j({ ok: true })
    }
    if (b.action === 'delete') {
      if (b.user_id === user.id) return j({ error: 'حساب خودتان را نمی‌توانید حذف کنید' }, 400)
      const { error } = await admin.auth.admin.deleteUser(b.user_id)
      return error ? j({ error: error.message }, 400) : j({ ok: true })
    }

    const nid = String(b.national_id || '').replace(/\D/g, '')
    if (nid.length !== 10 || !String(b.full_name || '').trim() || String(b.password || '').length < 6)
      return j({ error: 'اطلاعات ناقص یا نامعتبر است' }, 400)

    const { data, error } = await admin.auth.admin.createUser({
      email: `${nid}@alavi.app`, password: b.password, email_confirm: true,
    })
    if (error) return j({ error: error.message.includes('already') ? 'این کد ملی قبلاً ثبت شده' : error.message }, 400)

    const { error: e2 } = await admin.from('profiles').insert({
      id: data.user.id, national_id: nid, full_name: String(b.full_name).trim(),
      role: b.role === 'admin' ? 'admin' : 'student',
      class_name: b.class_name || null, phone: b.phone || null,
    })
    if (e2) { await admin.auth.admin.deleteUser(data.user.id); return j({ error: e2.message }, 400) }
    return j({ ok: true })
  } catch (e) {
    return j({ error: String(e) }, 500)
  }
})
