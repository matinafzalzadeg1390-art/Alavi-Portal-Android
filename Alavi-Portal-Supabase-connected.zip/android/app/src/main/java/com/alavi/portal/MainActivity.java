package com.alavi.portal;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    // آدرس سایت (GitHub Pages). اگر نام ریپو یا کاربر عوض شد، این خط را تغییر بده.
    private static final String SITE = "https://matinafzalzadeg1390-art.github.io/Alavi-Portal-Android/";
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#6A0A1E"));
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= 26) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#7D0B20"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    v.loadDataWithBaseURL(null,
                        "<html dir='rtl'><body style='font-family:sans-serif;text-align:center;padding:80px 24px;background:#7d0b20;color:#fff'>"
                        + "<h2>اتصال برقرار نشد</h2><p>اینترنت خود را بررسی کنید.</p>"
                        + "<button style='padding:14px 30px;border-radius:14px;border:0;font-size:16px' onclick=\"location.href='" + SITE + "'\">تلاش دوباره</button>"
                        + "</body></html>", "text/html", "utf-8", null);
                }
            }
        });
        setContentView(web);
        web.loadUrl(SITE);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.alaviBack ? window.alaviBack() : 0", value -> {
            if (!"1".equals(value)) {
                finish();
            }
        });
    }
}
