/* پرتال علوی — حالت ارائه (Presentation Mode)
 * فقط برای نمایش رابط کاربری است و «سیستم احراز هویت» نیست.
 * همه‌ی داده‌ها ساختگی‌اند، در حافظه‌ی همین تب (sessionStorage) می‌مانند،
 * هیچ‌وقت با Supabase تماس نمی‌گیرند و با داده‌ی واقعی مخلوط نمی‌شوند.
 * هیچ رمز، کلید یا اطلاعات محرمانه‌ای در این فایل وجود ندارد.
 * این فایل قبل از اسکریپت اصلی بارگذاری می‌شود؛ پس به توابع صفحه (esc, ic, toast, ...) فقط داخل توابع دسترسی دارد.
 */
(function () {
  'use strict';
  const KD = 'alavi-demo-data-v1', KR = 'alavi-demo-role-v1', ME_ID = 's1';
  const mem = {};
  const store = {
    get: k => { try { return sessionStorage.getItem(k) } catch (e) { return mem[k] || null } },
    set: (k, v) => { try { sessionStorage.setItem(k, v) } catch (e) { mem[k] = v } },
    del: k => { try { sessionStorage.removeItem(k) } catch (e) { delete mem[k] } }
  };
  const Q = s => document.querySelector(s), QA = s => [...document.querySelectorAll(s)];
  const enabled = () => (window.ALAVI || {}).presentation !== false;

  const ICONS = {
    msg: '<path d="M5 5h14a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-8l-4.5 3.5V16H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z"/>',
    cal: '<rect x="4" y="5.5" width="16" height="14.5" rx="3"/><path d="M8 3.5v4M16 3.5v4M4 10.5h16"/>',
    grp: '<circle cx="12" cy="8" r="3"/><circle cx="5.5" cy="10" r="2.2"/><circle cx="18.5" cy="10" r="2.2"/><path d="M6.5 19c.4-3 2.5-4.5 5.5-4.5s5.1 1.5 5.5 4.5M2.5 17.5c.2-2 1.4-3 3-3.2M21.5 17.5c-.2-2-1.4-3-3-3.2"/>',
    send: '<path d="M20 4 10.5 13.5M20 4l-6 16-3.5-6.5L4 10z"/>',
    swap: '<path d="M7 7h12l-3-3M17 17H5l3 3"/>',
    back: '<path d="m9 6 6 6-6 6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
    reset: '<path d="M4 12a8 8 0 1 0 2.6-5.9L4 8.5"/><path d="M4 4v4.5h4.5"/>'
  };

  /* ---------- داده‌ی ساختگی ---------- */
  const SUBJ = ['ریاضی', 'فیزیک', 'شیمی', 'ادبیات فارسی', 'زبان انگلیسی', 'زیست‌شناسی', 'هندسه'];
  const CLASSES = ['دهم الف', 'دهم ب', 'یازدهم الف'];
  const NAMES = [['آرمان', 'سلیمانی'], ['سارا', 'محمدی'], ['امیرحسین', 'رستمی'], ['مهسا', 'کریمی'], ['پارسا', 'نوروزی'], ['نگار', 'فرهادی'], ['کیان', 'صادقی'], ['الهام', 'حیدری'], ['رضا', 'جعفری'], ['هانیه', 'اکبری'], ['سینا', 'قاسمی'], ['یاسمن', 'طاهری']];
  const DAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه'];
  const SLOT = ['۰۸:۰۰ – ۰۹:۱۵', '۰۹:۳۰ – ۱۰:۴۵', '۱۱:۰۰ – ۱۲:۱۵', '۱۲:۳۰ – ۱۳:۴۵'];
  const SUPPORT_NAME = 'پشتیبان نمایشی';
  const rng = a => () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296 };
  const p2 = n => String(n).padStart(2, '0'), p4 = n => String(n).padStart(4, '0');
  const isoDay = d => d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());
  const ago = h => new Date(Date.now() - h * 36e5).toISOString();

  function seed() {
    const r = rng(1405);
    const students = NAMES.map((n, i) => {
      const grades = {}; SUBJ.forEach(s => { grades[s] = Math.min(20, Math.round((11 + r() * 9) * 4) / 4) });
      const att = [], d = new Date(); d.setHours(12);
      while (att.length < 20) { d.setDate(d.getDate() - 1); const w = d.getDay(); if (w === 4 || w === 5) continue; const x = r(); att.push({ day: isoDay(d), status: x < .08 ? 'absent' : x < .2 ? 'late' : 'present' }) }
      return { id: 's' + (i + 1), name: n[0] + ' ' + n[1], cls: CLASSES[i < 4 ? 0 : i < 8 ? 1 : 2], nid: '00000000' + p2(i + 1), phone: '0900000' + p4(i + 1), grades, att };
    });
    const ann = [
      { id: 5, title: 'آزمون زبان انگلیسی', body: 'آزمون زبان انگلیسی کلاس دهم ب روز چهارشنبه برگزار می‌شود.', kind: 'exam', audience: 'دهم ب', created_at: ago(6) },
      { id: 4, title: 'ثبت‌نام کلاس‌های تقویتی', body: 'ثبت‌نام کلاس‌های تقویتی ریاضی و فیزیک تا پایان هفته انجام می‌شود.', kind: 'general', audience: 'all', created_at: ago(30) },
      { id: 3, title: 'تغییر ساعت زنگ اول', body: 'زنگ اول کلاس دهم الف از هفته‌ی آینده نیم ساعت دیرتر شروع می‌شود.', kind: 'general', audience: 'دهم الف', created_at: ago(55) },
      { id: 2, title: 'اردوی علمی', body: 'ثبت‌نام اردوی علمی پایه‌ی دهم و یازدهم از امروز آغاز شده است.', kind: 'event', audience: 'all', created_at: ago(80) },
      { id: 1, title: 'آزمون میان‌ترم ریاضی', body: 'آزمون میان‌ترم ریاضی روز یکشنبه برگزار می‌شود. محدوده: فصل‌های ۱ تا ۳.', kind: 'exam', audience: 'all', created_at: ago(120) }
    ];
    const M = (by, text, h) => ({ by, text, ts: ago(h) });
    const chats = [
      { id: 'c1', type: 'direct', title: '', members: ['s1'], msgs: [M('s1', 'سلام، برای آزمون ریاضی منبع اضافه‌ای معرفی می‌کنید؟', 5), M('support', 'سلام. نمونه‌سؤال‌های فصل ۲ و ۳ را به‌زودی در اطلاعیه‌ها می‌گذاریم.', 4.5), M('support', 'اگر سؤال دیگری داشتید همین‌جا بنویسید.', 4.4)], seen: { support: 3, s1: 1 } },
      { id: 'c2', type: 'group', title: 'گروه کلاس دهم الف', members: ['s1', 's2', 's3', 's4'], msgs: [M('sys', 'گروه ساخته شد', 70), M('support', 'سلام بچه‌ها؛ برنامه‌ی هفته‌ی آینده در بخش برنامه‌ی درسی است.', 26), M('s2', 'ممنون. تکلیف فیزیک تا کی است؟', 3)], seen: { support: 2, s1: 2 } },
      { id: 'c3', type: 'group', title: 'گروه المپیاد ریاضی', members: ['s1', 's3', 's6', 's9'], msgs: [M('sys', 'گروه ساخته شد', 100), M('support', 'جلسه‌ی بعدی روز سه‌شنبه ساعت ۱۴ است.', 48)], seen: { support: 2, s1: 2 } },
      { id: 'c4', type: 'direct', title: '', members: ['s2'], msgs: [M('s2', 'سلام، می‌خواستم درباره‌ی نمره‌ی شیمی سؤال بپرسم.', 2)], seen: { support: 0 } },
      { id: 'c5', type: 'direct', title: '', members: ['s7'], msgs: [M('support', 'یادآوری: لطفاً فرم اردو را تا پایان هفته تحویل دهید.', 20), M('s7', 'چشم، ممنون.', 19)], seen: { support: 2, s7: 2 } },
      { id: 'c6', type: 'group', title: 'گروه کلاس دهم ب', members: ['s5', 's6', 's7', 's8'], msgs: [M('sys', 'گروه ساخته شد', 90), M('s5', 'برنامه‌ی آزمون انگلیسی مشخص شد؟', 8), M('support', 'بله، روز چهارشنبه؛ جزئیات در اطلاعیه‌ها هست.', 7)], seen: { support: 3 } }
    ];
    return { students, ann, chats, nextAnn: 6, nextChat: 7 };
  }

  /* ---------- حالت و ذخیره‌سازی ---------- */
  let S = null, R = null, ready = false;
  const UI = { tab: 'home', chat: null, filter: 'all', q: '', sq: '', sc: '' };
  const init = () => { if (ready) return; ready = true; Object.assign(I, ICONS) };
  const save = () => store.set(KD, JSON.stringify(S));
  function load() { try { const d = JSON.parse(store.get(KD)); if (d && d.students && d.chats && d.ann) { S = d; return } } catch (e) { } S = seed(); save() }
  const stu = id => S.students.find(s => s.id === id);
  const me = () => stu(ME_ID);
  const meId = () => R === 'support' ? 'support' : ME_ID;
  const chat = id => S.chats.find(c => c.id === id);
  const avg = s => { const v = Object.values(s.grades); return v.reduce((a, b) => a + b, 0) / v.length };
  const attPct = s => Math.round(s.att.filter(x => x.status !== 'absent').length / s.att.length * 100);
  const annFor = c => S.ann.filter(a => a.audience === 'all' || a.audience === c).sort((a, b) => b.created_at.localeCompare(a.created_at));
  const tmStr = iso => new Date(iso).toLocaleString('fa-IR', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  const clsIdx = c => Math.max(0, CLASSES.indexOf(c));
  const periodSubj = (cls, di, pi) => SUBJ[(di * 3 + pi * 2 + clsIdx(cls)) % SUBJ.length];
  const todayIdx = () => { const m = { 6: 0, 0: 1, 1: 2, 2: 3, 3: 4 }; const d = new Date().getDay(); return d in m ? m[d] : 0 };
  const kindCls = k => ({ exam: 'ac-r', event: 'ac-b', general: 'ac-a' }[k] || 'ac-a');

  /* ---------- نقطه‌ی ورود ---------- */
  function buttons() {
    if (!enabled()) return '';
    init();
    return '<div class="dsep"><span>حالت ارائه</span></div><div class="dlog">' +
      '<button class="btn b-soft" onclick="Demo.start(\'student\')">' + ic('stu') + 'ورود نمایشی دانش‌آموز</button>' +
      '<button class="btn b-soft" onclick="Demo.start(\'support\')">' + ic('usr') + 'ورود نمایشی پشتیبان</button></div>' +
      '<small>حالت ارائه فقط برای نمایش رابط است. اطلاعات آن کاملاً ساختگی است و به سامانه‌ی واقعی وصل نیست.</small>';
  }
  function start(role) {
    if (!enabled() || (role !== 'student' && role !== 'support')) return;
    init(); load(); R = role; store.set(KR, role);
    UI.tab = role === 'student' ? 'home' : 'dash'; UI.chat = null; UI.filter = 'all'; UI.q = ''; UI.sq = ''; UI.sc = '';
    document.body.classList.remove('menu'); closeM(); render(); scrollTo(0, 0);
  }
  function resume() {
    if (!enabled()) return false;
    const r = store.get(KR); if (r !== 'student' && r !== 'support') return false;
    start(r); return true;
  }
  const active = () => R !== null;
  function clearRole() { R = null; store.del(KR) }
  function logout() { clearRole(); document.body.classList.remove('menu'); closeM(); boot() }
  function end() { clearRole(); store.del(KD); S = null; document.body.classList.remove('menu'); closeM(); boot(); toast('حالت ارائه پایان یافت و داده‌های نمایشی پاک شد') }
  function swap() { const to = R === 'student' ? 'support' : 'student'; start(to); toast(to === 'student' ? 'به پنل دانش‌آموز نمایشی رفتید' : 'به پنل پشتیبان نمایشی رفتید') }
  function reset() { S = seed(); save(); UI.chat = null; render(); toast('داده‌های نمایشی به حالت اولیه برگشت') }
  function back() {
    if (Q('#mo').classList.contains('on')) { closeM(); return 1 }
    if (document.body.classList.contains('menu')) { document.body.classList.remove('menu'); return 1 }
    if (UI.chat) { closeChat(); return 1 }
    const home = R === 'student' ? 'home' : 'dash';
    if (UI.tab !== home) { tab(home); return 1 }
    return 0;
  }
  const render = () => R === 'student' ? sShell() : pShell();
  const tab = t => R === 'student' ? sTab(t) : pTab(t);

  /* ---------- پنل دانش‌آموز ---------- */
  const ST = [['home', 'خانه', 'home'], ['grades', 'نمرات', 'grd'], ['sched', 'برنامه', 'cal'], ['att', 'حضور', 'att'], ['ann', 'اطلاعیه', 'ann'], ['msg', 'پیام', 'msg']];
  function sShell() {
    const m = me(), h = new Date().getHours(), g = h < 5 ? 'شب بخیر' : h < 12 ? 'صبح بخیر' : h < 17 ? 'روز بخیر' : h < 20 ? 'عصر بخیر' : 'شب بخیر';
    Q('#root').innerHTML = '<div class="sapp"><header class="sh"><div><span class="dbadge">' + ic('info') + 'حالت ارائه</span><br><small>' + g + '</small><h2>' + esc(m.name.split(' ')[0]) + '</h2><span class="chipc">' + esc(m.cls) + '</span></div>' +
      '<div class="dtools"><button class="ib" onclick="Demo.tab(\'me\')" aria-label="پروفایل" title="پروفایل">' + ic('usr') + '</button><button class="ib" onclick="Demo.swap()" aria-label="رفتن به پنل پشتیبان" title="رفتن به پنل پشتیبان">' + ic('swap') + '</button><button class="ib" onclick="Demo.logout()" aria-label="خروج" title="خروج">' + ic('out') + '</button></div></header>' +
      '<div class="sm-main" id="sm"></div><nav class="sn d6">' + ST.map(t => '<button data-t="' + t[0] + '" onclick="Demo.tab(\'' + t[0] + '\')">' + ic(t[2]) + t[1] + '<span class="nbd" id="nb-' + t[0] + '" hidden></span></button>').join('') + '</nav></div>';
    sTab(UI.tab);
  }
  function unreadTotal() { const v = meId(); return S.chats.filter(c => R === 'support' || c.members.includes(ME_ID)).reduce((n, c) => n + unread(c, v), 0) }
  function updBadge() {
    const n = unreadTotal();
    const b = Q('#nb-msg'); if (b) { b.hidden = !n; b.textContent = fa(n) }
    const p = Q('#nb-chat'); if (p) { p.hidden = !n; p.textContent = fa(n) }
  }
  function sTab(t) {
    UI.tab = t; UI.chat = null;
    QA('.sn button').forEach(b => b.classList.toggle('on', b.dataset.t === t));
    const f = { home: sHome, grades: sGrades, sched: sSched, att: sAtt, ann: sAnn, msg: sMsg, me: sMe }[t];
    Q('#sm').innerHTML = '<div class="pg" ' + (t === 'home' ? '' : 'style="padding-top:24px"') + '>' + f() + '</div>';
    updBadge(); scrollTo(0, 0);
  }
  function sHome() {
    const m = me(), av = avg(m), ab = m.att.filter(x => x.status === 'absent').length, ur = unreadTotal(), di = todayIdx();
    return '<div class="stats"><div class="stat ac-r"><small>معدل</small><strong>' + fa(av.toFixed(2)) + '</strong></div><div class="stat ac-t"><small>درصد حضور</small><strong>' + fa(attPct(m)) + '٪</strong></div><div class="stat ac-b"><small>پیام خوانده‌نشده</small><strong>' + fa(ur) + '</strong></div><div class="stat ac-a"><small>غیبت</small><strong>' + fa(ab) + '</strong></div></div>' +
      '<div class="card" style="margin-bottom:18px"><div class="row" style="padding:0"><div class="who ac-r"><span>' + esc(ini(m.name)) + '</span></div><div><b>' + esc(m.name) + '</b><small>' + esc(m.cls) + ' · پروفایل نمایشی</small></div><button class="btn b-soft sm end" style="margin-inline-start:auto;font-size:12px;color:var(--ink)" onclick="Demo.tab(\'me\')">پروفایل</button></div></div>' +
      '<div class="sec-h">برنامه‌ی ' + DAYS[di] + '</div><div class="card" style="padding:8px 20px;margin-bottom:18px">' + dayRows(m.cls, di) + '</div>' +
      '<div class="sec-h">آخرین اطلاعیه‌ها</div><div class="card" style="padding:8px 20px">' + (annFor(m.cls).slice(0, 3).length ? annRows(annFor(m.cls).slice(0, 3)) : empty('ann', 'اطلاعیه‌ای نیست', 'وقتی مدرسه پیامی بفرستد اینجا می‌بینید')) + '</div>';
  }
  function sGrades() {
    const m = me(), av = avg(m), E = Object.entries(m.grades);
    return '<div class="sec-h">نمرات من</div><div class="card" style="margin-bottom:16px;text-align:center"><small style="color:var(--mut)">میانگین</small><div style="font-size:40px;font-weight:800;color:var(--red)">' + fa(av.toFixed(2)) + '</div></div>' +
      '<div class="card" style="padding:8px 20px">' + E.map((x, i) => '<div class="row ' + AC[i % 5] + '" style="display:block"><div style="display:flex;justify-content:space-between"><b>' + esc(x[0]) + '</b><b style="color:var(--a)">' + fa(x[1]) + '</b></div><div class="bar"><b style="width:' + x[1] * 5 + '%"></b></div></div>').join('') + '</div>';
  }
  function dayRows(cls, di) {
    return [0, 1, 2, 3].map(pi => '<div class="per ' + AC[(pi + di) % 5] + '"><span class="bar2"></span><div><b>' + esc(periodSubj(cls, di, pi)) + '</b><small>کلاس ' + fa(201 + clsIdx(cls)) + '</small></div><span class="tm end" style="margin-inline-start:auto">' + SLOT[pi] + '</span></div>').join('');
  }
  function sSched(d) {
    const di = typeof d === 'number' ? d : (UI.day == null ? todayIdx() : UI.day); UI.day = di;
    return '<div class="sec-h">برنامه‌ی درسی هفتگی</div><div class="dchips">' + DAYS.map((n, i) => '<button class="' + (i === di ? 'on' : '') + '" onclick="Demo.day(' + i + ')">' + n + '</button>').join('') + '</div><div class="card" style="padding:8px 20px" id="dayc">' + dayRows(me().cls, di) + '</div>';
  }
  function day(i) { UI.day = i; Q('#sm').innerHTML = '<div class="pg" style="padding-top:24px">' + sSched(i) + '</div>' }
  function sAtt() {
    const m = me(), S_ = { present: ['حاضر', 'ac-t'], late: ['تأخیر', 'ac-a'], absent: ['غایب', 'ac-r'] }, c = k => m.att.filter(x => x.status === k).length;
    return '<div class="sec-h">حضور و غیاب</div><div class="stats" style="margin:0 0 18px;grid-template-columns:repeat(3,1fr)"><div class="stat ac-t"><small>حاضر</small><strong style="font-size:26px">' + fa(c('present')) + '</strong></div><div class="stat ac-a"><small>تأخیر</small><strong style="font-size:26px">' + fa(c('late')) + '</strong></div><div class="stat ac-r"><small>غایب</small><strong style="font-size:26px">' + fa(c('absent')) + '</strong></div></div>' +
      '<div class="card" style="padding:8px 20px">' + m.att.map(x => '<div class="row"><b>' + fdate(x.day) + '</b><span class="pill end ' + S_[x.status][1] + '" style="font-size:12px">' + S_[x.status][0] + '</span></div>').join('') + '</div>';
  }
  function sAnn() {
    const L = annFor(me().cls);
    return '<div class="sec-h">اطلاعیه‌ها</div><div class="card" style="padding:8px 20px">' + (L.length ? annRows(L) : empty('ann', 'اطلاعیه‌ای نیست', 'وقتی مدرسه پیامی بفرستد اینجا می‌بینید')) + '</div>';
  }
  function sMsg() { return '<div class="sec-h">پیام‌ها</div>' + chatArea() }
  function sMe() {
    const m = me();
    return '<div class="sec-h">پروفایل</div><div class="card" style="margin-bottom:16px"><div class="row" style="padding-top:0"><div class="who ac-r"><span>' + esc(ini(m.name)) + '</span></div><div><b>' + esc(m.name) + '</b><small>' + esc(m.cls) + '</small></div></div>' +
      '<div class="row"><small>کد ملی (نمونه)</small><b class="end" style="font-size:14px;color:var(--ink)">' + fa(m.nid) + '</b></div><div class="row"><small>تلفن (نمونه)</small><b class="end" style="font-size:14px;color:var(--ink)">' + fa(m.phone) + '</b></div>' +
      '<div class="row"><small>معدل</small><b class="end" style="font-size:14px;color:var(--ink)">' + fa(avg(m).toFixed(2)) + '</b></div><div class="row"><small>درصد حضور</small><b class="end" style="font-size:14px;color:var(--ink)">' + fa(attPct(m)) + '٪</b></div></div>' + demoCard();
  }
  function demoCard() {
    return '<div class="card" style="margin-bottom:16px"><h3>حالت ارائه</h3><p style="color:var(--mut);font-size:13px;line-height:2;margin-bottom:14px">این بخش فقط نمایشی است. اطلاعات ساختگی‌اند، به Supabase وصل نیستند و با داده‌ی واقعی مخلوط نمی‌شوند.</p><div class="f2">' +
      '<button class="btn b-soft" onclick="Demo.swap()">' + ic('swap') + (R === 'student' ? 'رفتن به پنل پشتیبان نمایشی' : 'رفتن به پنل دانش‌آموز نمایشی') + '</button>' +
      '<button class="btn b-soft" onclick="Demo.reset()">' + ic('reset') + 'بازنشانی داده‌های نمایشی</button>' +
      '<button class="btn b-dg" onclick="Demo.end()">' + ic('out') + 'پایان حالت ارائه و بازگشت به صفحه ورود</button></div></div>' +
      '<button class="btn b-soft" style="width:100%" onclick="Demo.logout()">' + ic('out') + 'خروج از حساب نمایشی</button>';
  }

  /* ---------- گفت‌وگوها (مشترک بین دو پنل) ---------- */
  const unread = (c, v) => c.msgs.slice(c.seen[v] || 0).filter(m => m.by !== v && m.by !== 'sys').length;
  const cname = c => c.type === 'group' ? c.title : (R === 'support' ? stu(c.members[0]).name : 'پشتیبان مدرسه');
  const senderName = by => by === 'support' ? 'پشتیبان' : (stu(by) || { name: '—' }).name;
  const visChats = () => S.chats.filter(c => R === 'support' || c.members.includes(ME_ID));
  const lastTs = c => (c.msgs[c.msgs.length - 1] || { ts: '' }).ts;
  function filtered() {
    const q = UI.q.trim();
    return visChats().filter(c => (UI.filter === 'all' || c.type === UI.filter) && (!q || cname(c).includes(q))).sort((a, b) => lastTs(b).localeCompare(lastTs(a)));
  }
  function chatListHtml() {
    const L = filtered(), v = meId();
    return L.map((c, i) => {
      const u = unread(c, v), l = c.msgs[c.msgs.length - 1];
      const pv = l ? (l.by === 'sys' ? l.text : (l.by === v ? 'شما: ' : (c.type === 'group' ? senderName(l.by) + ': ' : '')) + l.text) : 'بدون پیام';
      return '<button class="citem ' + AC[i % 5] + (c.id === UI.chat ? ' on' : '') + '" onclick="Demo.openChat(\'' + c.id + '\')"><span class="av">' + (c.type === 'group' ? ic('grp') : esc(ini(cname(c)))) + '</span><span class="tx"><b>' + esc(cname(c)) + '</b><small>' + esc(pv) + '</small></span>' + (u ? '<span class="ubd">' + fa(u) + '</span>' : '') + '</button>';
    }).join('') || empty('msg', 'گفت‌وگویی پیدا نشد', R === 'support' ? 'با «پیام جدید» یا «گروه جدید» شروع کنید' : 'پیام‌های شما اینجا نمایش داده می‌شود');
  }
  function chatArea() {
    const F = [['all', 'همه'], ['group', 'گروه‌ها'], ['direct', 'خصوصی']];
    return '<div class="chatgrid ' + (UI.chat ? 'open ' : '') + (R === 'student' ? 'one' : '') + '"><div class="card cl"><div class="dchips">' + F.map(f => '<button class="' + (UI.filter === f[0] ? 'on' : '') + '" onclick="Demo.filt(\'' + f[0] + '\')">' + f[1] + '</button>').join('') + '</div><div id="cl">' + chatListHtml() + '</div></div>' +
      '<div class="cwp">' + (UI.chat ? chatWin() : '<div class="card cw">' + empty('msg', 'گفت‌وگویی را انتخاب کنید', 'یک گفت‌وگو یا گروه را از فهرست باز کنید') + '</div>') + '</div></div>';
  }
  function bubbles(c) {
    const v = meId();
    return c.msgs.map(m => m.by === 'sys' ? '<div class="bub sys">' + esc(m.text) + '</div>' :
      '<div class="bub ' + (m.by === v ? 'me' : '') + '">' + (c.type === 'group' && m.by !== v ? '<em>' + esc(senderName(m.by)) + '</em>' : '') + esc(m.text) + '<i>' + tmStr(m.ts) + '</i></div>').join('');
  }
  function chatWin() {
    const c = chat(UI.chat), g = c.type === 'group';
    const sub = g ? fa(c.members.length) + ' دانش‌آموز + پشتیبان' : (R === 'support' ? esc(stu(c.members[0]).cls) + ' · گفت‌وگوی خصوصی' : 'گفت‌وگوی خصوصی');
    return '<div class="card cw"><div class="ch ' + AC[0] + '"><button class="ab bk" onclick="Demo.closeChat()" aria-label="بازگشت">' + ic('back') + '</button><span class="av">' + (g ? ic('grp') : esc(ini(cname(c)))) + '</span><div style="min-width:0;flex:1"><b>' + esc(cname(c)) + '</b><small>' + sub + '</small></div>' +
      (g ? '<button class="ab" onclick="Demo.members(\'' + c.id + '\')" title="اعضا" aria-label="اعضا">' + ic('stu') + '</button>' : (R === 'support' ? '<button class="ab" onclick="Demo.viewStu(\'' + c.members[0] + '\')" title="اطلاعات دانش‌آموز" aria-label="اطلاعات دانش‌آموز">' + ic('eye') + '</button>' : '')) + '</div>' +
      '<div class="msgs" id="msgs">' + bubbles(c) + '</div><div class="cin"><input class="in" id="cin" maxlength="500" placeholder="پیام خود را بنویسید..." autocomplete="off" onkeydown="if(event.key===\'Enter\')Demo.send()"><button class="btn b-red" onclick="Demo.send()" aria-label="ارسال">' + ic('send') + '</button></div></div>';
  }
  function scrollMsgs() { const m = Q('#msgs'); if (m) m.scrollTop = m.scrollHeight }
  function refreshChats(full) {
    if (full) { const t = UI.tab; if (R === 'student') { Q('#sm').innerHTML = '<div class="pg" style="padding-top:24px">' + sMsg() + '</div>' } else { Q('#ap').innerHTML = '<div class="pg">' + pChat() + '</div>' } }
    scrollMsgs(); updBadge();
  }
  function openChat(id) { const c = chat(id); if (!c) return; UI.chat = id; c.seen[meId()] = c.msgs.length; save(); refreshChats(true); const w = Q('.cw'); if (R === 'student' && w) w.scrollIntoView({ block: 'start' }); const i = Q('#cin'); if (i && innerWidth > 860) i.focus() }
  function closeChat() { UI.chat = null; refreshChats(true); if (R === 'student') scrollTo(0, 0) }
  function filt(f) { UI.filter = f; refreshChats(true) }
  function cq(v) { UI.q = v; const l = Q('#cl'); if (l) l.innerHTML = chatListHtml() }
  function send() {
    const i = Q('#cin'); if (!i) return; const t = i.value.trim(); if (!t || !UI.chat) return;
    const c = chat(UI.chat), v = meId();
    c.msgs.push({ by: v, text: t, ts: new Date().toISOString() }); c.seen[v] = c.msgs.length; save();
    i.value = ''; Q('#msgs').innerHTML = bubbles(c); const l = Q('#cl'); if (l) l.innerHTML = chatListHtml(); scrollMsgs(); i.focus(); updBadge();
  }
  function directWith(sid) {
    let c = S.chats.find(x => x.type === 'direct' && x.members[0] === sid);
    if (!c) { c = { id: 'c' + S.nextChat++, type: 'direct', title: '', members: [sid], msgs: [], seen: { support: 0 } }; S.chats.push(c); save() }
    return c;
  }
  function msgStu(sid) { closeM(); UI.filter = 'all'; UI.q = ''; const c = directWith(sid); pTab('chat'); openChat(c.id) }
  function newDirect() {
    modal('<h3>پیام جدید</h3><label class="f">دانش‌آموز<select id="nds">' + S.students.map(s => '<option value="' + s.id + '">' + esc(s.name) + ' — ' + esc(s.cls) + '</option>').join('') + '</select></label><div class="mf"><button class="btn b-soft" onclick="closeM()">انصراف</button><button class="btn b-red" onclick="Demo.doDirect()">شروع گفت‌وگو</button></div>');
  }
  function doDirect() { msgStu(Q('#nds').value) }
  function newGroup() {
    modal('<h3>گروه جدید</h3><div class="f2"><label class="f">نام گروه<input class="in" id="gn" maxlength="40" placeholder="مثلاً گروه مشاوره"></label><label class="f">افزودن سریع کل کلاس<select id="gq" onchange="Demo.quickCls(this.value)"><option value="">انتخاب کلاس...</option>' + CLASSES.map(c => '<option>' + esc(c) + '</option>').join('') + '</select></label></div>' +
      '<div class="mlist" style="margin-top:12px">' + S.students.map(s => '<label class="chk"><input type="checkbox" class="gm" value="' + s.id + '" data-c="' + esc(s.cls) + '">' + esc(s.name) + '<small style="color:var(--mut);margin-inline-start:auto">' + esc(s.cls) + '</small></label>').join('') + '</div>' +
      '<div class="mf"><button class="btn b-soft" onclick="closeM()">انصراف</button><button class="btn b-red" onclick="Demo.doGroup()">ساخت گروه</button></div>');
  }
  function quickCls(c) { QA('.gm').forEach(x => { if (x.dataset.c === c) x.checked = true }) }
  function doGroup() {
    const n = Q('#gn').value.trim(), ids = QA('.gm:checked').map(x => x.value);
    if (!n) { toast('نام گروه را وارد کنید', 'err'); return }
    if (!ids.length) { toast('حداقل یک عضو انتخاب کنید', 'err'); return }
    const c = { id: 'c' + S.nextChat++, type: 'group', title: n, members: ids, seen: { support: 1 }, msgs: [{ by: 'sys', text: 'گروه ساخته شد', ts: new Date().toISOString() }] };
    S.chats.push(c); save(); closeM(); UI.filter = 'all'; UI.q = ''; toast('گروه ساخته شد'); pTab('chat'); openChat(c.id);
  }
  function members(cid) {
    const c = chat(cid), sup = R === 'support';
    const non = S.students.filter(s => !c.members.includes(s.id));
    modal('<h3>اعضای ' + esc(c.title) + '</h3><div class="mlist gl">' + '<div class="row ac-v" style="padding:6px 0"><div class="who"><span>' + ic('usr') + '</span>' + SUPPORT_NAME + '</div><span class="pill end">مدیر گروه</span></div>' +
      c.members.map((id, i) => { const s = stu(id); return '<div class="row ' + AC[i % 5] + '" style="padding:6px 0"><div class="who"><span>' + esc(ini(s.name)) + '</span><div><div>' + esc(s.name) + '</div><small style="font-weight:400;color:var(--mut)">' + esc(s.cls) + '</small></div></div>' + (sup ? '<button class="ab dg end" style="margin-inline-start:auto" title="حذف از گروه" onclick="Demo.rmMember(\'' + cid + '\',\'' + id + '\')">' + ic('trash') + '</button>' : '') + '</div>' }).join('') + '</div>' +
      (sup && non.length ? '<div class="tools" style="margin:16px 0 0"><select id="am">' + non.map(s => '<option value="' + s.id + '">' + esc(s.name) + '</option>').join('') + '</select><button class="btn b-red sm" onclick="Demo.addMember(\'' + cid + '\')">' + ic('plus') + 'افزودن</button></div>' : '') +
      '<div class="mf"><button class="btn b-soft" onclick="closeM()">بستن</button></div>');
  }
  function sysMsg(c, t) { c.msgs.push({ by: 'sys', text: t, ts: new Date().toISOString() }); c.seen.support = c.msgs.length }
  function rmMember(cid, sid) { const c = chat(cid); c.members = c.members.filter(x => x !== sid); sysMsg(c, stu(sid).name + ' از گروه حذف شد'); save(); members(cid); refreshChats(true) }
  function addMember(cid) { const c = chat(cid), sid = Q('#am').value; if (!sid) return; c.members.push(sid); sysMsg(c, stu(sid).name + ' به گروه اضافه شد'); save(); members(cid); refreshChats(true) }

  /* ---------- پنل پشتیبان ---------- */
  const PN = [['dash', 'داشبورد', 'dash'], ['stu', 'دانش‌آموزان', 'stu'], ['chat', 'گفت‌وگوها و گروه‌ها', 'msg'], ['ann', 'اطلاعیه‌ها', 'ann'], ['set', 'حالت ارائه', 'set']];
  function pShell() {
    Q('#root').innerHTML = '<div class="scrim" onclick="document.body.classList.remove(\'menu\')"></div><div class="aapp"><aside class="side"><div class="brand"><div class="logo">ع</div><div><b>پرتال علوی</b><small>پنل پشتیبان (نمایشی)</small></div></div>' +
      PN.map(n => '<button class="nav" data-t="' + n[0] + '" onclick="Demo.tab(\'' + n[0] + '\')">' + ic(n[2]) + n[1] + (n[0] === 'chat' ? '<span class="nbd" id="nb-chat" hidden></span>' : '') + '</button>').join('') +
      '<div class="me"><b>' + SUPPORT_NAME + '</b><span>پشتیبان · داده‌ی ساختگی</span></div></aside>' +
      '<div class="main"><header class="top"><button class="ib burger" onclick="document.body.classList.add(\'menu\')" aria-label="منو">' + ic('menu') + '</button><h1 id="pt"></h1><span class="dbadge lt">' + ic('info') + 'حالت ارائه</span><span style="flex:1"></span>' +
      '<button class="btn b-soft sm" onclick="Demo.swap()" title="رفتن به پنل دانش‌آموز" aria-label="رفتن به پنل دانش‌آموز نمایشی">' + ic('swap') + '<span class="lb">دانش‌آموز نمایشی</span></button><button class="btn b-soft sm" onclick="Demo.logout()" aria-label="خروج">' + ic('out') + '<span class="lb">خروج</span></button></header><section class="page" id="ap"></section></div></div>';
    pTab(UI.tab);
  }
  function pTab(t) {
    UI.tab = t; UI.chat = (t === 'chat') ? UI.chat : null; document.body.classList.remove('menu');
    QA('.nav').forEach(b => b.classList.toggle('on', b.dataset.t === t));
    Q('#pt').textContent = PN.find(x => x[0] === t)[1];
    const f = { dash: pDash, stu: pStu, chat: pChat, ann: pAnn, set: pSet }[t];
    Q('#ap').innerHTML = '<div class="pg">' + f() + '</div>';
    if (t === 'stu') stuRows(); updBadge(); scrollTo(0, 0);
  }
  function pDash() {
    const st = S.students, av = st.reduce((a, s) => a + avg(s), 0) / st.length, ur = unreadTotal();
    const K = [['stu', 'دانش‌آموزان', fa(st.length), 'ac-r'], ['msg', 'گفت‌وگوها و گروه‌ها', fa(S.chats.length), 'ac-b'], ['ann', 'اطلاعیه‌های منتشرشده', fa(S.ann.length), 'ac-a'], ['grd', 'میانگین کل نمرات', fa(av.toFixed(2)), 'ac-t']];
    const unr = S.chats.filter(c => unread(c, 'support')).sort((a, b) => lastTs(b).localeCompare(lastTs(a)));
    return '<div class="kpis">' + K.map(k => '<div class="kpi ' + k[3] + '"><div class="ico">' + ic(k[0]) + '</div><small>' + k[1] + '</small><strong>' + k[2] + '</strong></div>').join('') + '</div>' +
      '<div class="g2"><div class="card"><h3>پیام‌های خوانده‌نشده<span class="pill" style="margin-inline-start:auto">' + fa(ur) + '</span></h3>' +
      (unr.length ? unr.map((c, i) => '<div class="row ' + AC[i % 5] + '" style="cursor:pointer" onclick="Demo.tab(\'chat\');Demo.openChat(\'' + c.id + '\')"><i>' + ic(c.type === 'group' ? 'grp' : 'msg') + '</i><div><b>' + esc(cname(c)) + '</b><small>' + fa(unread(c, 'support')) + ' پیام جدید</small></div></div>').join('') : empty('msg', 'پیام جدیدی نیست', 'همه‌ی گفت‌وگوها خوانده شده‌اند')) + '</div>' +
      '<div class="card"><h3>آخرین اطلاعیه‌ها<button class="btn b-soft sm" onclick="Demo.tab(\'ann\')">مدیریت</button></h3>' + annRows(S.ann.slice().sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 4)) + '</div></div>';
  }
  function pStu() {
    return '<div class="tools"><input class="in" id="sq" placeholder="جستجوی نام، کد ملی یا کلاس..." value="' + esc(UI.sq) + '" oninput="Demo.sq(this.value)"><select id="sc" onchange="Demo.sc(this.value)"><option value="">همه کلاس‌ها</option>' + CLASSES.map(c => '<option' + (UI.sc === c ? ' selected' : '') + '>' + esc(c) + '</option>').join('') + '</select></div>' +
      '<div class="card tw"><table><thead><tr><th>نام</th><th>کد ملی (نمونه)</th><th>کلاس</th><th>تلفن (نمونه)</th><th>معدل</th><th>عملیات</th></tr></thead><tbody id="stb"></tbody></table></div>';
  }
  const sq = v => { UI.sq = v; stuRows() }, sc = v => { UI.sc = v; stuRows() };
  function stuRows() {
    const q = UI.sq.trim(), c = UI.sc, n = norm(q);
    const L = S.students.filter(s => (!c || s.cls === c) && (!q || s.name.includes(q) || (n && s.nid.includes(n)) || s.cls.includes(q)));
    Q('#stb').innerHTML = L.map((s, i) => '<tr><td><div class="who ' + AC[i % 5] + '"><span>' + esc(ini(s.name)) + '</span>' + esc(s.name) + '</div></td><td dir="ltr" style="text-align:right">' + fa(s.nid) + '</td><td>' + esc(s.cls) + '</td><td dir="ltr" style="text-align:right">' + fa(s.phone) + '</td><td><span class="pill ac-t">' + fa(avg(s).toFixed(2)) + '</span></td>' +
      '<td><div class="acts"><button class="ab" title="مشاهده اطلاعات" aria-label="مشاهده اطلاعات" onclick="Demo.viewStu(\'' + s.id + '\')">' + ic('eye') + '</button><button class="ab" title="ارسال پیام" aria-label="ارسال پیام" onclick="Demo.msgStu(\'' + s.id + '\')">' + ic('msg') + '</button></div></td></tr>').join('') || '<tr><td colspan="6">' + empty('stu', 'نتیجه‌ای پیدا نشد', 'عبارت دیگری را جستجو کنید') + '</td></tr>';
  }
  function viewStu(id) {
    const s = stu(id), c = k => s.att.filter(x => x.status === k).length;
    modal('<h3>' + esc(s.name) + '</h3><div class="row" style="padding-top:0"><div class="who ac-r"><span>' + esc(ini(s.name)) + '</span></div><div><b>' + esc(s.cls) + '</b><small>اطلاعات نمایشی</small></div></div>' +
      '<div class="row"><small>کد ملی (نمونه)</small><b class="end" style="font-size:14px;color:var(--ink)">' + fa(s.nid) + '</b></div><div class="row"><small>تلفن (نمونه)</small><b class="end" style="font-size:14px;color:var(--ink)">' + fa(s.phone) + '</b></div>' +
      '<div class="row"><small>معدل</small><b class="end" style="font-size:14px;color:var(--ink)">' + fa(avg(s).toFixed(2)) + '</b></div><div class="row"><small>حضور / تأخیر / غیبت</small><b class="end" style="font-size:14px;color:var(--ink)">' + fa(c('present')) + ' / ' + fa(c('late')) + ' / ' + fa(c('absent')) + '</b></div>' +
      '<div style="margin-top:8px">' + Object.entries(s.grades).map((x, i) => '<div class="' + AC[i % 5] + '" style="margin-top:10px"><div style="display:flex;justify-content:space-between;font-size:13px"><b>' + esc(x[0]) + '</b><b style="color:var(--a)">' + fa(x[1]) + '</b></div><div class="bar"><b style="width:' + x[1] * 5 + '%"></b></div></div>').join('') + '</div>' +
      '<div class="mf"><button class="btn b-soft" onclick="closeM()">بستن</button><button class="btn b-red" onclick="Demo.msgStu(\'' + id + '\')">' + ic('msg') + 'ارسال پیام</button></div>');
  }
  function pChat() {
    return '<div class="tools"><input class="in" id="cq" placeholder="جستجوی گفت‌وگو یا گروه..." value="' + esc(UI.q) + '" oninput="Demo.cq(this.value)"><button class="btn b-soft" onclick="Demo.newDirect()">' + ic('msg') + 'پیام جدید</button><button class="btn b-red" onclick="Demo.newGroup()">' + ic('plus') + 'گروه جدید</button></div>' + chatArea();
  }
  const audOpts = sel => '<option value="all">همه دانش‌آموزان</option>' + CLASSES.map(c => '<option' + (sel === c ? ' selected' : '') + '>' + esc(c) + '</option>').join('');
  const kindOpts = sel => [['general', 'اطلاعیه عمومی'], ['exam', 'آزمون'], ['event', 'رویداد']].map(k => '<option value="' + k[0] + '"' + (sel === k[0] ? ' selected' : '') + '>' + k[1] + '</option>').join('');
  function pAnn() {
    const L = S.ann.slice().sort((a, b) => b.created_at.localeCompare(a.created_at));
    return '<div class="g2"><div class="card"><h3>اطلاعیه جدید</h3><div class="f2"><label class="f">عنوان<input class="in" id="at" maxlength="80"></label><label class="f">متن<textarea class="in" id="ab" maxlength="400"></textarea></label><label class="f">نوع<select id="ak">' + kindOpts('general') + '</select></label><label class="f">مخاطب<select id="au">' + audOpts('all') + '</select></label><button class="btn b-red" onclick="Demo.annAdd()">' + ic('ann') + 'انتشار برای دانش‌آموزان</button></div></div>' +
      '<div class="card"><h3>منتشرشده‌ها</h3>' + (L.length ? L.map(a => '<div class="row ' + kindCls(a.kind) + '"><i>' + ic(a.kind === 'exam' ? 'grd' : a.kind === 'event' ? 'att' : 'ann') + '</i><div style="min-width:0"><b>' + esc(a.title) + '</b><small>' + esc(a.audience === 'all' ? 'همه' : a.audience) + ' · ' + fdate(a.created_at) + '</small></div><div class="acts end" style="margin-inline-start:auto"><button class="ab" title="ویرایش" aria-label="ویرایش" onclick="Demo.annEdit(' + a.id + ')">' + ic('edit') + '</button><button class="ab dg" title="حذف" aria-label="حذف" onclick="Demo.annDel(' + a.id + ')">' + ic('trash') + '</button></div></div>').join('') : empty('ann', 'اطلاعیه‌ای نیست', 'فرم کنار را پر کنید')) + '</div></div>';
  }
  function annAdd() {
    const t = Q('#at').value.trim(), b = Q('#ab').value.trim();
    if (!t || !b) { toast('عنوان و متن را وارد کنید', 'err'); return }
    S.ann.push({ id: S.nextAnn++, title: t, body: b, kind: Q('#ak').value, audience: Q('#au').value, created_at: new Date().toISOString() }); save(); toast('اطلاعیه منتشر شد'); pTab('ann');
  }
  function annEdit(id) {
    const a = S.ann.find(x => x.id === id); if (!a) return;
    modal('<h3>ویرایش اطلاعیه</h3><div class="f2"><label class="f">عنوان<input class="in" id="et" maxlength="80" value="' + esc(a.title) + '"></label><label class="f">متن<textarea class="in" id="eb" maxlength="400">' + esc(a.body) + '</textarea></label><label class="f">نوع<select id="ek">' + kindOpts(a.kind) + '</select></label><label class="f">مخاطب<select id="eu">' + audOpts(a.audience) + '</select></label></div><div class="mf"><button class="btn b-soft" onclick="closeM()">انصراف</button><button class="btn b-red" onclick="Demo.annSave(' + id + ')">ذخیره</button></div>');
  }
  function annSave(id) {
    const a = S.ann.find(x => x.id === id), t = Q('#et').value.trim(), b = Q('#eb').value.trim();
    if (!t || !b) { toast('عنوان و متن را وارد کنید', 'err'); return }
    a.title = t; a.body = b; a.kind = Q('#ek').value; a.audience = Q('#eu').value; save(); closeM(); toast('اطلاعیه ذخیره شد'); pTab('ann');
  }
  function annDel(id) {
    const a = S.ann.find(x => x.id === id); if (!a) return;
    modal('<h3>حذف اطلاعیه؟</h3><p style="color:var(--mut);font-size:13px;line-height:2">«' + esc(a.title) + '» از اطلاعیه‌های نمایشی حذف می‌شود.</p><div class="mf"><button class="btn b-soft" onclick="closeM()">انصراف</button><button class="btn b-dg" onclick="Demo.annDelOk(' + id + ')">بله، حذف شود</button></div>');
  }
  function annDelOk(id) { S.ann = S.ann.filter(x => x.id !== id); save(); closeM(); toast('اطلاعیه حذف شد'); pTab('ann') }
  function pSet() { return '<div class="g2"><div class="card"><h3>درباره‌ی حالت ارائه</h3><p style="color:var(--mut);font-size:13px;line-height:2.1">این نسخه فقط برای نمایش رابط کاربری است و سیستم ورود واقعی نیست. همه‌ی اطلاعات ساختگی‌اند و فقط در همین تب مرورگر نگه‌داری می‌شوند. هیچ داده‌ای به Supabase ارسال یا از آن خوانده نمی‌شود.</p></div><div>' + demoCard() + '</div></div>' }

  window.Demo = { buttons, start, resume, active, clearRole, back, logout, end, swap, reset, tab, day, openChat, closeChat, filt, cq, send, msgStu, newDirect, doDirect, newGroup, quickCls, doGroup, members, rmMember, addMember, sq, sc, viewStu, annAdd, annEdit, annSave, annDel, annDelOk };
})();
