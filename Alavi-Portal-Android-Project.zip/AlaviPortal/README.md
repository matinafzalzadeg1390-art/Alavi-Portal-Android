# پرتال علوی — نسخه دمو (اندروید)

دموی رابط کاربری پرتال دانش‌آموزی علوی. اپ یک پوسته‌ی اندرویدی است که صفحه‌ی `app/src/main/assets/index.html` را نمایش می‌دهد؛ همه‌ی داده‌ها نمونه و ساختگی‌اند.

## ساخت و دانلود فایل نصب (APK)

1. یک مخزن (Repository) جدید در GitHub بساز، مثلاً `alavi-portal-demo`، و عمومی (Public) بگذارش.
2. محتویات همین پوشه را در آن آپلود کن (پوشه‌ی `.github` هم باید باشد):

   ```bash
   git init
   git add .
   git commit -m "Alavi portal demo"
   git branch -M main
   git remote add origin https://github.com/USERNAME/alavi-portal-demo.git
   git push -u origin main
   ```

3. در GitHub به تب **Actions** برو. ساخت خودکار شروع می‌شود (حدود ۵ تا ۸ دقیقه).
4. بعد از سبز شدن، از صفحه‌ی اصلی مخزن، بخش **Releases** (سمت راست) را باز کن و `Alavi-Portal-Demo.apk` را دانلود کن.

## نصب روی اندروید

1. فایل APK را روی گوشی دانلود کن و باز کن.
2. اگر خواست، اجازه‌ی «نصب از این منبع» را بده.
3. اگر Play Protect هشدار داد، «Install anyway / نصب به هر حال» را بزن (چون نسخه‌ی دمو با کلید دیباگ امضا شده).

## تغییر ظاهر

فایل `app/src/main/assets/index.html` را ویرایش کن و دوباره push کن؛ APK جدید خودکار ساخته می‌شود.
