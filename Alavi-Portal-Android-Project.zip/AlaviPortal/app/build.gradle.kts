plugins {
    id("com.android.application")
}

android {
    namespace = "com.alavi.portal"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.alavi.portal"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-demo"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
